
valor = 0

def contagem(valor):
    valor = int(input("diga o valor que você quer a contagem regressiva! "))
    for x in range(valor, 0, -1):
      print(x)

contagem(valor)
print("parabens feliz aniversario")

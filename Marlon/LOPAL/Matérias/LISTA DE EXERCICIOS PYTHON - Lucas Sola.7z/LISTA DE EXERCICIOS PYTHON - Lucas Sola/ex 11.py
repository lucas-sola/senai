#-*- coding: UTF-8 -*-

#entrada de dados

nota1 = float(input("diga aqui a sua primeira nota"))
nota2 = float(input("Diga o aqui a sua segunda nota"))

#calculo e variações


if (nota1 + nota2) / 2 >= 7.0 and (nota1 + nota2) / 2 <= 10.0:
    print("Aprovado")
elif (nota1 + nota2) / 2 > 0 and (nota1 + nota2) / 2 <  3.0:
    print("reprovado")
elif (nota1 + nota2) / 2 > 3.0 and (nota1 + nota2) / 2 < 7.0:
    print("Recuperação")

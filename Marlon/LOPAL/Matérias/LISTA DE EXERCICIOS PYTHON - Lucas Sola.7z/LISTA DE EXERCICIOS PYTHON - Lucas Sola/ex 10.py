#-*- coding: UTF-8 -*-

#entrada de dados

v1 = int(input("Diga um valor real "))
v2 = int(input("Diga um valor real"))
v3 = int(input("Diga um valor real"))

#vendo se configura um triangulo 


if v1 > v2 + v3:
    print("este valor não configura um triangulo!")
elif v2 > v1 + v3:
    print("este valor não configura um triangulo!")
elif v3 > v2 + v1:
    print("este valor não configura um triangulo!")
    

#calculo e variações
if v1 == v2 and v1 == v3:
    print("Triangulo equilatero")
elif v1 == v2 and v1 == v3:
    print("Triangulo isosceles")
elif v2 == v3 and v2 == v1:
    print("Triangulo isosceles")
elif v3 == v2 and v3 == v1:
    print("Triangulo isosceles")
elif v1 != v2 and v1 != v3:
    print("Triangulo escaleno")
elif v2 != v3 and v2 != v1:
    print("Triangulo escaleno")
elif v3 != v1 and v3 != v2:
    print("triangulo escaleno")

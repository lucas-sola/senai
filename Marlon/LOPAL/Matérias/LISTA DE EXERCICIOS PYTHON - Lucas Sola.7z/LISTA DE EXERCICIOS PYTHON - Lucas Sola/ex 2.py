#-*- coding: UTF-8 -*-
import math

#entrada de dados

v1 = int(input("Diga aqui um número"))

#calculo e decisões

if v1 < 0:
    print(" o número é inferior a 0, ou seja, negativo, então vamos elevar ao quadrado, e o resultado é:", v1 * v1)
elif v1 > 0:
    v2 = math.sqrt(v1)
    print("O valor é positivo, então vamos tirar a raiz quadrada dele! o valor final é:", v2)

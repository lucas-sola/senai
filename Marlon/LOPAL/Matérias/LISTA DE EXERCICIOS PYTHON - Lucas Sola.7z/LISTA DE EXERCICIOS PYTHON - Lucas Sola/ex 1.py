#-*- coding: UTF-8 -*-

#entrada de dados


n1 = int(input("Diga dois número, caso a soma dele seja maior que 20, somaremos 8. caso seja inferior ou igual a 20, subtrairemos 5: "))
n2= int(input("diga o segundo valor:"))


#calculo 


if n1 + n2 > 20:
    print("o valor é:", n1 + n2 + 8)
elif n1 + n2 <= 20:
    print("o valor é:",n1 + n2 - 5 )
    

#-*- coding: UTF-8 -*-

#entrada de dados

num1  = int(input("Diga um valor e eu direi se ele é impar ou par"))


#calculo


if num1  % 2 == 0:
    print("O número é par.")
else:
    print("O número é impar")

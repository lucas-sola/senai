#-*- coding: UTF-8 -*-

#entrada de dados

valor = float(input("Digite aqui o valor do objeto"))
valor_1= valor + (valor * 45) / 100
valor_2= valor + (valor * 30) / 100


#calculo e variações
if valor < 20:
    print(valor_1, "este é o seu valor")
elif valor > 20:
    print(valor_2, "este é o seu valor")


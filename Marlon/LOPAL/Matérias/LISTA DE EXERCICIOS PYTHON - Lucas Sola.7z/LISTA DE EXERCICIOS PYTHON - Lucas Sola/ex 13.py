#-*- coding: UTF-8 -*-

#entrada de dados

nota1 = float(input("Diga o valor de sua nota"))
nota2 = float(input("Diga o valor de sua nota"))
nota3 = float(input("Diga o valor de sua nota"))
media = (nota1 + nota2 + nota3) / 3
falta = int(input("Diga a quantidade de faltas"))



#calculo e variações


if media < 7 and media > 0 :
    print("Reprovado")
elif falta > 20:
    print("reprovado por faltas")
elif media > 7 and media < 10 :
    print("Aprovado")

#-*- coding: UTF-8 -*-

#entrada de dados


A = int(input("Digite um número e eu direi se ele é divisível pelo outro número(denominador)."))
B = int(input("digite o outro número(divisor):"))


#calculo 


if A % B == 0:
    print("O número é divisível pelo outro.")
else:
    print("O número não é divisível pelo outro.")

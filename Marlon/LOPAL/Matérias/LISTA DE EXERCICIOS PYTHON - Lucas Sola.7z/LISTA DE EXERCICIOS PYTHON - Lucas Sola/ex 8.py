#-*- coding: UTF-8 -*-

#entrada de dados

salario = float(input("Digite aqui seu salário bruto:"))
prestacao = float(input("Digite aqui sua prestação:"))
salario1 = (salario *  30) / 100

#variação e calculo
if prestacao > salario1:
    print("Não é possível fazer o empréstimo. O valor excede 30% do salario bruto.")
else:
    print("Você pode continuar com o empréstimo, siga em frente.")

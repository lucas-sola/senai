#-*- coding: UTF-8 -*-

#entrada de dados

A = int(input("Diga dois números e eu direi em uma forma crescente."))
B = int(input("Digite o segundo valor aqui"))

#calculo
if A > B:
    A, B = B, A
    print(f"A = {A}, B = {B}" )
elif B > A:
    print(f"A = {A}), B = {B}" ) 

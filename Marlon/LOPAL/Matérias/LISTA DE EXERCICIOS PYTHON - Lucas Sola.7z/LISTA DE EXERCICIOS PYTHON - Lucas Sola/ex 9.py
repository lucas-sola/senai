#-*- coding: UTF-8 -*-

#entrada de dados

peso = float(input("Digite aqui o peso do seu corpo(kg)."))
altura = float(input("Digite aqui a sua altura(m)."))

altura2 =(altura * altura)

#calculo e variações


if peso / altura2 < 20:
    print("Abaixo do peso")
elif peso / altura2 >= 20 and peso / altura2 < 25:
    print("peso normal")
elif peso / altura2 >= 25 and peso / altura2 <= 30:
    print("Sobre peso")
elif peso / altura2 > 30 and peso / altura2 <= 40:
    print("Obeso")
elif peso / altura2 > 40:
    print("Obeso mórbido.")

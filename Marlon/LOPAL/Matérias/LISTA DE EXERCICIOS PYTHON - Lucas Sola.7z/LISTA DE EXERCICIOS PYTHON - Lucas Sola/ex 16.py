#-*- coding: UTF-8 -*-

#entrada de dados

idade = int(input("Diga aqui sua idade"))

#calculo e variações
if  idade > 0 and idade < 3:
    print("Você é um bebê")
elif idade > 2 and  idade < 12:
    print("criança")
elif idade >= 12 and idade <= 23:
    print("adolescente")
elif idade  > 23 and idade  <= 70:
    print("adulto")
elif idade > 70 and idade < 130:
    print("idoso")



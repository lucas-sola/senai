#-*- coding: UTF-8 -*-


#entrada de dados
num = 19.50

horas_trabalhadas = int(input("Diga a quantidade de horas que você trabalhou este mês"))
salario = horas_trabalhadas * num 

num1 = (1500 * 10) / 100  #acima de 1500

#calculo

if salario > 1500:
    salario_liq = (salario * 10) / 100
    novo_sal = salario - salario_liq
    print("seu salário, contando com tributos é:", novo_sal)
else:
    print("Este é seu salário:", salario)

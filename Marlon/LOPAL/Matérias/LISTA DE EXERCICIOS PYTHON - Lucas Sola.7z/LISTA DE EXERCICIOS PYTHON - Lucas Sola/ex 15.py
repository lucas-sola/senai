#-*- coding: UTF-8 -*-

#entrada de dados

temp = int(input("Diga aqui a temperatura"))

#calculo e variações


if  temp > 0 and temp < 16:
    print("muito frio")
elif temp >= 16 and  temp < 23:
    print("frio")
elif temp >= 23 and temp < 26:
    print("agradável")
elif temp  > 25 and temp  <= 30:
    print("calor")
elif temp > 30:
    print("muito quente")



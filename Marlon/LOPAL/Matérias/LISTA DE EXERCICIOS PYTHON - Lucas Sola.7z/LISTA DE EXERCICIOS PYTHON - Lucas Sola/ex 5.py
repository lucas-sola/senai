#-*- coding: UTF-8 -*-

#entrada de dados

num1  = int(input("Diga um valor e eu direi se é divisível por 3 ou não."))

#calculo

if num1  % 3 == 0:
    print("O número é divisível por 3")
else:
    print("O número nao é divisível por 3")

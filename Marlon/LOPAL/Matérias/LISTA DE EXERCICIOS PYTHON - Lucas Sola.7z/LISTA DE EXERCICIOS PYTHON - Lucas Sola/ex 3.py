#-*-coding: UTF-8 -*-

#pegando informações

v1 = int(input("Diga um número de cada vez e eu direi qual é o maior deles: "))

v2 = int(input("Diga o segundo número "))

#vendo se os números sao iguais

if v1 == v2:
    print("Digite dois números diferentes ")

#verificando o número

if v1 > v2:
         print("maior número é:", v1)
else:
    print("O maior número é:", v2)




#-*- coding: UTF-8 -*-

#programa para executar a lista de 1 a 50 e depois de 50 a 1.

for i in range(1, 51):
    print (i)
for i in range(50,  0, -1):
    print (i)
